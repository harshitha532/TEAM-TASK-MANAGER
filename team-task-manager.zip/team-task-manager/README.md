# Taskline — Team Task Manager

A full-stack team task manager with **role-based access control** (Admin / Member).
Create projects, invite members, assign tasks, track status and spot overdue work
from a live dashboard.

Built with **MongoDB + Express + React (Vite) + Node.js** and designed for a
one-click **Railway** deployment.

---

## Features

- JWT authentication (Signup / Login) with bcrypt password hashing
- Role-based access control (Admin vs Member)
  - **Admin**: full control — create/delete projects, manage members, CRUD any task, change user roles
  - **Member**: view projects they belong to, create tasks, update assigned tasks, update their status
- Projects + team management (add / remove members)
- Tasks: title, description, assignee, status (Todo / In Progress / Done), priority, due date
- Kanban board view per project
- Dashboard with live stats (Total, Todo, In Progress, Done, **Overdue**)
- Clean dark productivity UI (Linear / Notion inspired)
- REST API with validation and relationship integrity
- Ready for Railway deployment (single service)

---

## Tech stack

| Layer     | Tech                                             |
|-----------|--------------------------------------------------|
| Frontend  | React 18, Vite, React Router, Tailwind CSS, Axios, lucide-react |
| Backend   | Node.js, Express, Mongoose, JWT, bcryptjs, express-validator    |
| Database  | MongoDB                                          |

---

## Project structure

```
team-task-manager/
├── backend/
│   ├── src/
│   │   ├── config/db.js
│   │   ├── middleware/auth.js
│   │   ├── models/{User,Project,Task}.js
│   │   ├── routes/{auth,projects,tasks,users}.js
│   │   └── server.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── api/client.js
│   │   ├── context/AuthContext.jsx
│   │   ├── pages/{Login,Register,Dashboard,ProjectDetail,Team}.jsx
│   │   ├── components/Navbar.jsx
│   │   ├── App.jsx · main.jsx · index.css
│   ├── package.json
│   ├── vite.config.js · tailwind.config.js · postcss.config.js
│   ├── index.html
│   └── .env.example
├── package.json            # root helper scripts
└── README.md
```

---

## Prerequisites

- **Node.js 18+** and **npm** (or **yarn**)
- A **MongoDB** database. Pick one:
  - **Local**: install MongoDB Community and run `mongod` (URI: `mongodb://localhost:27017/team_task_manager`)
  - **MongoDB Atlas (free)**: create a free cluster → copy the SRV connection string
    (https://www.mongodb.com/atlas)

---

## Getting started (local VS Code)

Clone or unzip the project, then in VS Code open a terminal in the project root.

### 1) Backend

```bash
cd backend
cp .env.example .env          # then edit .env with your MongoDB URI & JWT secret
npm install
npm run dev                   # http://localhost:5000
```

`backend/.env` example:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/team_task_manager
JWT_SECRET=please-change-me-to-a-long-random-string
JWT_EXPIRES_IN=7d
CLIENT_ORIGIN=http://localhost:5173
```

### 2) Frontend

Open a **second** terminal:

```bash
cd frontend
cp .env.example .env          # points to http://localhost:5000 by default
npm install
npm run dev                   # http://localhost:5173
```

### 3) First login

The **very first user you register becomes an Admin automatically**. All
subsequent users default to Member (unless explicitly registered as Admin).
Admins can later promote/demote anyone from the **Team** page.

---

## API reference

All routes are prefixed with `/api`. Protected routes require the header:
`Authorization: Bearer <token>`.

### Auth
- `POST /auth/register` — `{ name, email, password, role? }` → `{ token, user }`
- `POST /auth/login` — `{ email, password }` → `{ token, user }`
- `GET  /auth/me` — current user

### Projects
- `GET    /projects` — list projects visible to the user
- `POST   /projects` — *Admin* — `{ name, description?, members? }`
- `GET    /projects/:id` — project + its tasks
- `PUT    /projects/:id` — *Admin* — update name/description/members
- `DELETE /projects/:id` — *Admin* — deletes project + tasks
- `POST   /projects/:id/members` — *Admin* — `{ userId }`
- `DELETE /projects/:id/members/:userId` — *Admin*

### Tasks
- `GET    /tasks?project=&assignee=me&status=` — list (RBAC-filtered)
- `POST   /tasks` — any project member — `{ project, title, description?, assignee?, status?, priority?, dueDate? }`
- `PUT    /tasks/:id` — Admin/creator: any field; Assignee: status only
- `DELETE /tasks/:id` — Admin or creator
- `GET    /tasks/stats/summary` — dashboard counts

### Users
- `GET /users` — list all users (for pickers)
- `PUT /users/:id/role` — *Admin* — `{ role: 'Admin' | 'Member' }`

---

## Deploying to Railway

The backend is configured to **serve the built frontend** when `NODE_ENV=production`,
so you can deploy the whole app as **one Railway service**.

### Option A — Single service (recommended)

1. Push this repo to GitHub.
2. In **Railway** → **New Project** → **Deploy from GitHub repo**.
3. Add a **MongoDB** plugin (Railway → New → Database → MongoDB) **or** paste an
   Atlas connection string.
4. Set Railway **Variables** on the service:
   - `MONGO_URI` — from the Mongo plugin / Atlas
   - `JWT_SECRET` — any long random string
   - `NODE_ENV=production`
   - `CLIENT_ORIGIN` — your Railway public URL (e.g. `https://your-app.up.railway.app`)
5. Set the service **Root Directory** to the repo root.
6. **Build command**:
   ```
   npm install && npm run build
   ```
7. **Start command**:
   ```
   npm start
   ```
8. Hit "Deploy". Railway assigns a public URL — that's your **Live URL**.

The root `package.json` already wires up `build` (installs both workspaces and
builds the frontend) and `start` (runs the backend, which also serves the
frontend `dist/`).

### Option B — Two services

Deploy `backend/` and `frontend/` as separate services. Set
`VITE_API_URL` on the frontend service to the backend's public URL, and set
`CLIENT_ORIGIN` on the backend to the frontend's public URL.

---

## RBAC cheat-sheet

| Action                       | Admin | Member (project) | Member (assignee only) |
|-----------------------------|:-----:|:----------------:|:----------------------:|
| Create project              | ✅    | ❌               | ❌                     |
| Delete project              | ✅    | ❌               | ❌                     |
| Add/remove project members  | ✅    | ❌               | ❌                     |
| Create task in project      | ✅    | ✅               | ❌                     |
| Edit any task field         | ✅    | creator only     | ❌                     |
| Change task status          | ✅    | ✅ (creator)     | ✅ (own tasks)         |
| Delete task                 | ✅    | creator only     | ❌                     |
| Change user roles           | ✅    | ❌               | ❌                     |

---

## Scripts (root)

```bash
npm run install:all   # install both workspaces
npm run dev           # runs backend + frontend concurrently (needs concurrently)
npm run build         # installs deps and builds frontend
npm start             # starts backend (prod) serving the built frontend
```

---

## License

MIT — use it, ship it, remix it.
