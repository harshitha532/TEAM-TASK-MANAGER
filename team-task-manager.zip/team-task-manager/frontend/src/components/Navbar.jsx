import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogOut, LayoutDashboard, Users, Zap } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const linkClass = ({ isActive }) =>
    `px-3 py-1.5 rounded-md text-sm font-medium transition ${
      isActive ? 'bg-surface2 text-white' : 'text-muted hover:text-white'
    }`;

  return (
    <header className="border-b border-border bg-[#0b0d10]/80 backdrop-blur sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-5 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2" data-testid="brand-link">
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-accent to-accent2 flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="font-display text-xl text-white tracking-tight">Taskline</span>
        </Link>
        <nav className="flex items-center gap-1">
          <NavLink to="/" end className={linkClass} data-testid="nav-dashboard">
            <span className="inline-flex items-center gap-1.5">
              <LayoutDashboard className="w-4 h-4" /> Dashboard
            </span>
          </NavLink>
          {user?.role === 'Admin' && (
            <NavLink to="/team" className={linkClass} data-testid="nav-team">
              <span className="inline-flex items-center gap-1.5">
                <Users className="w-4 h-4" /> Team
              </span>
            </NavLink>
          )}
        </nav>
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-sm text-white leading-tight">{user?.name}</div>
            <div className="text-[11px] text-muted leading-tight">
              {user?.role} · {user?.email}
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="btn-ghost !py-1.5 !px-2.5"
            data-testid="logout-btn"
            title="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
