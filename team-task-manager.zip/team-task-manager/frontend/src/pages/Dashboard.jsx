import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';
import { Plus, FolderKanban, CheckCircle2, Clock, AlertTriangle, ListTodo, Trash2 } from 'lucide-react';

const StatCard = ({ icon: Icon, label, value, accent }) => (
  <div className="card p-4 flex items-center gap-3" data-testid={`stat-${label.toLowerCase().replace(/\s/g, '-')}`}>
    <div className={`w-10 h-10 rounded-lg grid place-items-center ${accent}`}>
      <Icon className="w-5 h-5" />
    </div>
    <div>
      <div className="text-xs uppercase tracking-wider text-muted">{label}</div>
      <div className="text-2xl font-semibold text-white leading-tight">{value}</div>
    </div>
  </div>
);

export default function Dashboard() {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [newProj, setNewProj] = useState({ name: '', description: '', members: [] });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const [p, s, u] = await Promise.all([
      api.get('/projects'),
      api.get('/tasks/stats/summary'),
      api.get('/users').catch(() => ({ data: [] })),
    ]);
    setProjects(p.data);
    setStats(s.data);
    setUsers(u.data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const createProject = async (e) => {
    e.preventDefault();
    await api.post('/projects', newProj);
    setNewProj({ name: '', description: '', members: [] });
    setShowNew(false);
    load();
  };

  const deleteProject = async (id) => {
    if (!confirm('Delete this project and all its tasks?')) return;
    await api.delete(`/projects/${id}`);
    load();
  };

  if (loading) return <div className="text-muted">Loading…</div>;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl text-white">
          Hello, {user.name.split(' ')[0]}.
        </h1>
        <p className="text-muted mt-1">
          {user.role === 'Admin'
            ? "Here's what your team is working on."
            : "Here's what's on your plate."}
        </p>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <StatCard icon={ListTodo} label="Total" value={stats.total} accent="bg-accent/15 text-accent" />
          <StatCard icon={FolderKanban} label="Todo" value={stats.todo} accent="bg-muted/15 text-muted" />
          <StatCard icon={Clock} label="In Progress" value={stats.inProgress} accent="bg-warn/15 text-warn" />
          <StatCard icon={CheckCircle2} label="Done" value={stats.done} accent="bg-success/15 text-success" />
          <StatCard icon={AlertTriangle} label="Overdue" value={stats.overdue} accent="bg-danger/15 text-danger" />
        </div>
      )}

      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-white">Projects</h2>
        {user.role === 'Admin' && (
          <button
            className="btn-primary"
            onClick={() => setShowNew(!showNew)}
            data-testid="new-project-btn"
          >
            <Plus className="w-4 h-4" /> New project
          </button>
        )}
      </div>

      {showNew && (
        <form onSubmit={createProject} className="card p-5 space-y-3" data-testid="new-project-form">
          <div>
            <label className="label">Project name</label>
            <input
              className="input"
              value={newProj.name}
              onChange={(e) => setNewProj({ ...newProj, name: e.target.value })}
              required
              data-testid="new-project-name"
            />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea
              rows={2}
              className="input"
              value={newProj.description}
              onChange={(e) => setNewProj({ ...newProj, description: e.target.value })}
              data-testid="new-project-desc"
            />
          </div>
          <div>
            <label className="label">Members</label>
            <select
              multiple
              className="input h-28"
              value={newProj.members}
              onChange={(e) =>
                setNewProj({
                  ...newProj,
                  members: Array.from(e.target.selectedOptions).map((o) => o.value),
                })
              }
              data-testid="new-project-members"
            >
              {users
                .filter((u) => u._id !== user.id)
                .map((u) => (
                  <option key={u._id} value={u._id}>
                    {u.name} — {u.email} ({u.role})
                  </option>
                ))}
            </select>
            <p className="text-xs text-muted mt-1">Hold Ctrl/Cmd to select multiple.</p>
          </div>
          <div className="flex gap-2 justify-end">
            <button type="button" className="btn-ghost" onClick={() => setShowNew(false)}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" data-testid="new-project-submit">
              Create
            </button>
          </div>
        </form>
      )}

      {projects.length === 0 ? (
        <div className="card p-10 text-center">
          <FolderKanban className="w-10 h-10 text-muted mx-auto mb-3" />
          <p className="text-muted">
            {user.role === 'Admin'
              ? "No projects yet. Create your first one above."
              : "You haven't been added to any projects yet."}
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map((p) => (
            <div key={p._id} className="card p-5 hover:border-accent/50 transition group relative">
              <Link to={`/projects/${p._id}`} className="block">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-white group-hover:text-accent transition">
                    {p.name}
                  </h3>
                </div>
                <p className="text-sm text-muted line-clamp-2 min-h-[2.5rem]">
                  {p.description || 'No description'}
                </p>
                <div className="flex items-center justify-between mt-4 text-xs text-muted">
                  <span>
                    {p.members.length + 1} member{p.members.length === 0 ? '' : 's'}
                  </span>
                  <span className="chip bg-surface2 border border-border text-muted">
                    Owner: {p.owner?.name}
                  </span>
                </div>
              </Link>
              {user.role === 'Admin' && (
                <button
                  className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition text-muted hover:text-danger"
                  onClick={() => deleteProject(p._id)}
                  data-testid={`delete-project-${p._id}`}
                  title="Delete project"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
