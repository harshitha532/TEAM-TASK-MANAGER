import { useEffect, useState } from 'react';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function Team() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data } = await api.get('/users');
    setUsers(data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const changeRole = async (id, role) => {
    await api.put(`/users/${id}/role`, { role });
    load();
  };

  if (user.role !== 'Admin') {
    return <div className="text-muted">Admins only.</div>;
  }
  if (loading) return <div className="text-muted">Loading…</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-4xl text-white">Team</h1>
        <p className="text-muted mt-1">Manage roles across your organization.</p>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-surface2 text-muted uppercase text-xs">
            <tr>
              <th className="text-left px-4 py-3">Name</th>
              <th className="text-left px-4 py-3">Email</th>
              <th className="text-left px-4 py-3">Role</th>
              <th className="text-right px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id} className="border-t border-border" data-testid={`user-row-${u._id}`}>
                <td className="px-4 py-3 text-white">{u.name}</td>
                <td className="px-4 py-3 text-muted">{u.email}</td>
                <td className="px-4 py-3">
                  <span
                    className={`chip ${
                      u.role === 'Admin'
                        ? 'bg-accent/15 text-accent'
                        : 'bg-surface2 border border-border text-[#cfd4df]'
                    }`}
                  >
                    {u.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  {u._id === user.id ? (
                    <span className="text-xs text-muted">You</span>
                  ) : (
                    <select
                      className="input !w-auto !py-1 text-xs"
                      value={u.role}
                      onChange={(e) => changeRole(u._id, e.target.value)}
                      data-testid={`role-select-${u._id}`}
                    >
                      <option value="Member">Member</option>
                      <option value="Admin">Admin</option>
                    </select>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
