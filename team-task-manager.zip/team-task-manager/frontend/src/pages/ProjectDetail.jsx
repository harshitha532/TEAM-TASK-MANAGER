import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, Plus, UserPlus, X, Calendar, Trash2, Pencil } from 'lucide-react';

const STATUSES = ['Todo', 'In Progress', 'Done'];
const PRIORITIES = ['Low', 'Medium', 'High'];

const priorityColor = {
  Low: 'bg-muted/15 text-muted',
  Medium: 'bg-accent2/15 text-accent2',
  High: 'bg-danger/15 text-danger',
};

const statusColor = {
  Todo: 'bg-muted/15 text-muted',
  'In Progress': 'bg-warn/15 text-warn',
  Done: 'bg-success/15 text-success',
};

const isOverdue = (t) =>
  t.dueDate && t.status !== 'Done' && new Date(t.dueDate) < new Date();

export default function ProjectDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNewTask, setShowNewTask] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const load = async () => {
    const [p, u] = await Promise.all([
      api.get(`/projects/${id}`),
      api.get('/users').catch(() => ({ data: [] })),
    ]);
    setProject(p.data.project);
    setTasks(p.data.tasks);
    setUsers(u.data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [id]);

  const isAdmin = user.role === 'Admin';
  const memberIds = useMemo(
    () =>
      project
        ? new Set([String(project.owner._id || project.owner), ...project.members.map((m) => String(m._id || m))])
        : new Set(),
    [project]
  );

  const availableToAdd = users.filter((u) => !memberIds.has(String(u._id)));

  const addMember = async (userId) => {
    await api.post(`/projects/${id}/members`, { userId });
    load();
  };

  const removeMember = async (userId) => {
    await api.delete(`/projects/${id}/members/${userId}`);
    load();
  };

  const deleteTask = async (taskId) => {
    if (!confirm('Delete this task?')) return;
    await api.delete(`/tasks/${taskId}`);
    load();
  };

  const updateStatus = async (taskId, status) => {
    await api.put(`/tasks/${taskId}`, { status });
    load();
  };

  if (loading || !project) return <div className="text-muted">Loading…</div>;

  const canEditTask = (t) =>
    isAdmin ||
    String(t.createdBy?._id) === String(user.id) ||
    String(t.assignee?._id) === String(user.id);

  return (
    <div className="space-y-8">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-white">
        <ArrowLeft className="w-4 h-4" /> Back to dashboard
      </Link>

      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl text-white">{project.name}</h1>
          <p className="text-muted mt-1 max-w-2xl">{project.description || 'No description'}</p>
        </div>
        <button
          onClick={() => setShowNewTask(true)}
          className="btn-primary"
          data-testid="new-task-btn"
        >
          <Plus className="w-4 h-4" /> New task
        </button>
      </div>

      {/* Members strip */}
      <div className="card p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Members</h3>
          {isAdmin && availableToAdd.length > 0 && (
            <select
              className="input !w-auto !py-1.5 text-sm"
              defaultValue=""
              onChange={(e) => e.target.value && addMember(e.target.value)}
              data-testid="add-member-select"
            >
              <option value="">+ Add member</option>
              {availableToAdd.map((u) => (
                <option key={u._id} value={u._id}>
                  {u.name} ({u.email})
                </option>
              ))}
            </select>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="chip bg-accent/15 text-accent border border-accent/30">
            {project.owner.name} · Owner
          </div>
          {project.members.map((m) => (
            <div
              key={m._id}
              className="chip bg-surface2 border border-border text-[#cfd4df]"
              data-testid={`member-${m._id}`}
            >
              {m.name}
              {isAdmin && (
                <button
                  onClick={() => removeMember(m._id)}
                  className="ml-1 text-muted hover:text-danger"
                  title="Remove member"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
          {project.members.length === 0 && !isAdmin && (
            <div className="text-sm text-muted">Only the owner for now.</div>
          )}
        </div>
      </div>

      {/* Kanban */}
      <div className="grid md:grid-cols-3 gap-4">
        {STATUSES.map((status) => {
          const col = tasks.filter((t) => t.status === status);
          return (
            <div key={status} className="card p-4" data-testid={`column-${status}`}>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-white">{status}</h3>
                <span className="chip bg-surface2 text-muted">{col.length}</span>
              </div>
              <div className="space-y-2 min-h-[100px]">
                {col.map((t) => (
                  <div
                    key={t._id}
                    className={`bg-surface2 border rounded-lg p-3 hover:border-accent/50 transition group ${
                      isOverdue(t) ? 'border-danger/50' : 'border-border'
                    }`}
                    data-testid={`task-${t._id}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="font-medium text-white text-sm leading-snug">{t.title}</div>
                      {canEditTask(t) && (
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
                          <button
                            onClick={() => setEditingTask(t)}
                            className="text-muted hover:text-white"
                            title="Edit"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          {(isAdmin || String(t.createdBy?._id) === String(user.id)) && (
                            <button
                              onClick={() => deleteTask(t._id)}
                              className="text-muted hover:text-danger"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                    {t.description && (
                      <p className="text-xs text-muted mt-1 line-clamp-2">{t.description}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <span className={`chip ${priorityColor[t.priority]}`}>{t.priority}</span>
                      {t.dueDate && (
                        <span
                          className={`chip bg-surface border border-border ${
                            isOverdue(t) ? 'text-danger' : 'text-muted'
                          }`}
                        >
                          <Calendar className="w-3 h-3" />
                          {new Date(t.dueDate).toLocaleDateString()}
                        </span>
                      )}
                      {t.assignee && (
                        <span className="chip bg-surface border border-border text-[#cfd4df]">
                          {t.assignee.name}
                        </span>
                      )}
                    </div>
                    {canEditTask(t) && (
                      <select
                        className="input !py-1 !text-xs mt-2"
                        value={t.status}
                        onChange={(e) => updateStatus(t._id, e.target.value)}
                        data-testid={`status-select-${t._id}`}
                      >
                        {STATUSES.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    )}
                  </div>
                ))}
                {col.length === 0 && (
                  <div className="text-xs text-muted text-center py-6">No tasks</div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {(showNewTask || editingTask) && (
        <TaskModal
          project={project}
          users={users}
          task={editingTask}
          onClose={() => {
            setShowNewTask(false);
            setEditingTask(null);
          }}
          onSaved={() => {
            setShowNewTask(false);
            setEditingTask(null);
            load();
          }}
          isAdmin={isAdmin}
          currentUser={user}
        />
      )}
    </div>
  );
}

function TaskModal({ project, users, task, onClose, onSaved, isAdmin, currentUser }) {
  const memberIds = new Set([
    String(project.owner._id || project.owner),
    ...project.members.map((m) => String(m._id || m)),
  ]);
  const assignable = users.filter((u) => memberIds.has(String(u._id)));

  const [form, setForm] = useState(
    task
      ? {
          title: task.title,
          description: task.description || '',
          assignee: task.assignee?._id || '',
          priority: task.priority,
          status: task.status,
          dueDate: task.dueDate ? task.dueDate.slice(0, 10) : '',
        }
      : {
          title: '',
          description: '',
          assignee: '',
          priority: 'Medium',
          status: 'Todo',
          dueDate: '',
        }
  );
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const isCreator = task && String(task.createdBy?._id) === String(currentUser.id);
  const canFullEdit = !task || isAdmin || isCreator;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setSaving(true);
    try {
      const payload = { ...form, project: project._id };
      if (!payload.assignee) payload.assignee = null;
      if (!payload.dueDate) payload.dueDate = null;
      if (task) {
        await api.put(`/tasks/${task._id}`, payload);
      } else {
        await api.post('/tasks', payload);
      }
      onSaved();
    } catch (err) {
      setError(err?.response?.data?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 grid place-items-center px-4"
      onClick={onClose}
      data-testid="task-modal"
    >
      <form
        className="card p-6 w-full max-w-lg space-y-4 relative"
        onClick={(e) => e.stopPropagation()}
        onSubmit={submit}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-3 right-3 text-muted hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-semibold text-white">
          {task ? 'Edit task' : 'New task'}
        </h2>

        <div>
          <label className="label">Title</label>
          <input
            className="input"
            value={form.title}
            disabled={!canFullEdit}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            required
            data-testid="task-title"
          />
        </div>
        <div>
          <label className="label">Description</label>
          <textarea
            rows={3}
            className="input"
            disabled={!canFullEdit}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            data-testid="task-desc"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Assignee</label>
            <select
              className="input"
              disabled={!canFullEdit}
              value={form.assignee}
              onChange={(e) => setForm({ ...form, assignee: e.target.value })}
              data-testid="task-assignee"
            >
              <option value="">Unassigned</option>
              {assignable.map((u) => (
                <option key={u._id} value={u._id}>
                  {u.name} ({u.role})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Priority</label>
            <select
              className="input"
              disabled={!canFullEdit}
              value={form.priority}
              onChange={(e) => setForm({ ...form, priority: e.target.value })}
              data-testid="task-priority"
            >
              {PRIORITIES.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Status</label>
            <select
              className="input"
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
              data-testid="task-status"
            >
              {STATUSES.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Due date</label>
            <input
              type="date"
              className="input"
              disabled={!canFullEdit}
              value={form.dueDate}
              onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              data-testid="task-due"
            />
          </div>
        </div>

        {error && (
          <div className="text-sm text-danger bg-danger/10 border border-danger/30 rounded-md px-3 py-2">
            {error}
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn-primary" disabled={saving} data-testid="task-save">
            {saving ? 'Saving…' : task ? 'Save changes' : 'Create task'}
          </button>
        </div>
      </form>
    </div>
  );
}
