import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'Member' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await register(form.name, form.email, form.password, form.role);
      navigate('/');
    } catch (err) {
      setError(err?.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid place-items-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-display text-4xl text-white mb-1">Create your account</h1>
          <p className="text-muted text-sm">The first user is auto-promoted to Admin.</p>
        </div>
        <form onSubmit={submit} className="card p-6 space-y-4" data-testid="register-form">
          <div>
            <label className="label">Name</label>
            <input
              data-testid="register-name"
              className="input"
              value={form.name}
              onChange={update('name')}
              required
            />
          </div>
          <div>
            <label className="label">Email</label>
            <input
              data-testid="register-email"
              type="email"
              className="input"
              value={form.email}
              onChange={update('email')}
              required
            />
          </div>
          <div>
            <label className="label">Password</label>
            <input
              data-testid="register-password"
              type="password"
              className="input"
              value={form.password}
              onChange={update('password')}
              required
              minLength={6}
            />
          </div>
          <div>
            <label className="label">Role</label>
            <select
              data-testid="register-role"
              className="input"
              value={form.role}
              onChange={update('role')}
            >
              <option value="Member">Member</option>
              <option value="Admin">Admin</option>
            </select>
            <p className="text-xs text-muted mt-1">
              Admins can manage projects, members, and all tasks.
            </p>
          </div>
          {error && (
            <div className="text-sm text-danger bg-danger/10 border border-danger/30 rounded-md px-3 py-2">
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full"
            data-testid="register-submit"
          >
            {loading ? 'Creating account…' : 'Create account'}
          </button>
          <p className="text-center text-sm text-muted">
            Have an account?{' '}
            <Link to="/login" className="text-accent hover:underline">
              Sign in
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
