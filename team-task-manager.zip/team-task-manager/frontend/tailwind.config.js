/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0b0d10',
        surface: '#12151b',
        surface2: '#191d25',
        border: '#262b35',
        accent: '#7c5cff',
        accent2: '#22d3ee',
        success: '#22c55e',
        warn: '#f59e0b',
        danger: '#ef4444',
        muted: '#8b94a6',
      },
      fontFamily: {
        sans: ['"Instrument Sans"', 'system-ui', 'sans-serif'],
        display: ['"Instrument Serif"', 'serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(124,92,255,0.35), 0 10px 40px -10px rgba(124,92,255,0.35)',
      },
    },
  },
  plugins: [],
};
