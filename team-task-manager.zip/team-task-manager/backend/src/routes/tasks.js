const express = require('express');
const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');
const Task = require('../models/Task');
const Project = require('../models/Project');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

const isProjectMember = (project, user) => {
  if (user.role === 'Admin') return true;
  if (String(project.owner) === String(user._id)) return true;
  return project.members.some((m) => String(m) === String(user._id));
};

// GET /api/tasks - filter: ?project= | ?assignee=me | ?status=
router.get('/', async (req, res, next) => {
  try {
    const { project, assignee, status } = req.query;
    const filter = {};
    if (project) filter.project = project;
    if (status) filter.status = status;

    if (assignee === 'me') {
      filter.assignee = req.user._id;
    } else if (assignee) {
      filter.assignee = assignee;
    }

    // Members see only tasks from projects they belong to
    if (req.user.role !== 'Admin') {
      const userProjects = await Project.find({
        $or: [{ owner: req.user._id }, { members: req.user._id }],
      }).select('_id');
      const ids = userProjects.map((p) => p._id);
      filter.project = filter.project
        ? { $in: ids.filter((id) => String(id) === String(filter.project)) }
        : { $in: ids };
    }

    const tasks = await Task.find(filter)
      .populate('assignee', 'name email role')
      .populate('createdBy', 'name email role')
      .populate('project', 'name')
      .sort({ dueDate: 1, createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    next(err);
  }
});

// POST /api/tasks - member of project can create
router.post(
  '/',
  [
    body('title').trim().notEmpty().withMessage('Title required'),
    body('project').notEmpty().withMessage('Project required'),
  ],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ message: errors.array()[0].msg });
      }
      const { title, description, project, assignee, status, priority, dueDate } = req.body;
      if (!mongoose.isValidObjectId(project)) {
        return res.status(400).json({ message: 'Invalid project id' });
      }
      const proj = await Project.findById(project);
      if (!proj) return res.status(404).json({ message: 'Project not found' });
      if (!isProjectMember(proj, req.user)) {
        return res.status(403).json({ message: 'Not a project member' });
      }

      const task = await Task.create({
        title,
        description,
        project,
        assignee: assignee || null,
        status: status || 'Todo',
        priority: priority || 'Medium',
        dueDate: dueDate || null,
        createdBy: req.user._id,
      });
      const populated = await task.populate([
        { path: 'assignee', select: 'name email role' },
        { path: 'createdBy', select: 'name email role' },
      ]);
      res.status(201).json(populated);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/tasks/:id
router.put('/:id', async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    const project = await Project.findById(task.project);
    if (!project) return res.status(404).json({ message: 'Project not found' });

    const isAdmin = req.user.role === 'Admin';
    const isCreator = String(task.createdBy) === String(req.user._id);
    const isAssignee = task.assignee && String(task.assignee) === String(req.user._id);
    const isMember = isProjectMember(project, req.user);

    if (!isMember) return res.status(403).json({ message: 'Forbidden' });

    const { title, description, assignee, status, priority, dueDate } = req.body;

    // Members who are only assignees can update status only
    if (!isAdmin && !isCreator) {
      if (!isAssignee) {
        return res.status(403).json({ message: 'Only admin/creator/assignee can edit' });
      }
      if (status !== undefined) task.status = status;
    } else {
      if (title !== undefined) task.title = title;
      if (description !== undefined) task.description = description;
      if (assignee !== undefined) task.assignee = assignee || null;
      if (status !== undefined) task.status = status;
      if (priority !== undefined) task.priority = priority;
      if (dueDate !== undefined) task.dueDate = dueDate || null;
    }

    await task.save();
    const populated = await task.populate([
      { path: 'assignee', select: 'name email role' },
      { path: 'createdBy', select: 'name email role' },
    ]);
    res.json(populated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/tasks/:id - Admin or creator
router.delete('/:id', async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });
    const isAdmin = req.user.role === 'Admin';
    const isCreator = String(task.createdBy) === String(req.user._id);
    if (!isAdmin && !isCreator) {
      return res.status(403).json({ message: 'Only admin/creator can delete' });
    }
    await task.deleteOne();
    res.json({ message: 'Task deleted' });
  } catch (err) {
    next(err);
  }
});

// GET /api/tasks/stats - dashboard counts for current user
router.get('/stats/summary', async (req, res, next) => {
  try {
    const isAdmin = req.user.role === 'Admin';
    const baseFilter = isAdmin ? {} : { assignee: req.user._id };

    const [total, todo, inProgress, done, overdue] = await Promise.all([
      Task.countDocuments(baseFilter),
      Task.countDocuments({ ...baseFilter, status: 'Todo' }),
      Task.countDocuments({ ...baseFilter, status: 'In Progress' }),
      Task.countDocuments({ ...baseFilter, status: 'Done' }),
      Task.countDocuments({
        ...baseFilter,
        status: { $ne: 'Done' },
        dueDate: { $ne: null, $lt: new Date() },
      }),
    ]);

    res.json({ total, todo, inProgress, done, overdue });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
