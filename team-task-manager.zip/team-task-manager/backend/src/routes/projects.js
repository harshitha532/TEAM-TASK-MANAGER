const express = require('express');
const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');
const Project = require('../models/Project');
const Task = require('../models/Task');
const User = require('../models/User');
const { protect, requireRole } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

// Helper: user can access project if Admin OR owner OR in members
const canAccessProject = (project, user) => {
  if (user.role === 'Admin') return true;
  if (String(project.owner) === String(user._id)) return true;
  return project.members.some((m) => String(m) === String(user._id));
};

// GET /api/projects - list projects visible to the user
router.get('/', async (req, res, next) => {
  try {
    const filter =
      req.user.role === 'Admin'
        ? {}
        : { $or: [{ owner: req.user._id }, { members: req.user._id }] };
    const projects = await Project.find(filter)
      .populate('owner', 'name email role')
      .populate('members', 'name email role')
      .sort({ createdAt: -1 });
    res.json(projects);
  } catch (err) {
    next(err);
  }
});

// POST /api/projects - Admin only
router.post(
  '/',
  requireRole('Admin'),
  [body('name').trim().notEmpty().withMessage('Project name required')],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ message: errors.array()[0].msg });
      }
      const { name, description = '', members = [] } = req.body;
      const project = await Project.create({
        name,
        description,
        owner: req.user._id,
        members: Array.from(new Set([...members])),
      });
      const populated = await project.populate([
        { path: 'owner', select: 'name email role' },
        { path: 'members', select: 'name email role' },
      ]);
      res.status(201).json(populated);
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/projects/:id - with tasks
router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid project id' });
    }
    const project = await Project.findById(req.params.id)
      .populate('owner', 'name email role')
      .populate('members', 'name email role');
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!canAccessProject(project, req.user)) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    const tasks = await Task.find({ project: project._id })
      .populate('assignee', 'name email role')
      .populate('createdBy', 'name email role')
      .sort({ createdAt: -1 });
    res.json({ project, tasks });
  } catch (err) {
    next(err);
  }
});

// PUT /api/projects/:id - Admin only
router.put('/:id', requireRole('Admin'), async (req, res, next) => {
  try {
    const { name, description, members } = req.body;
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (name !== undefined) project.name = name;
    if (description !== undefined) project.description = description;
    if (Array.isArray(members)) project.members = members;
    await project.save();
    const populated = await project.populate([
      { path: 'owner', select: 'name email role' },
      { path: 'members', select: 'name email role' },
    ]);
    res.json(populated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/projects/:id - Admin only
router.delete('/:id', requireRole('Admin'), async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    await Task.deleteMany({ project: project._id });
    await project.deleteOne();
    res.json({ message: 'Project deleted' });
  } catch (err) {
    next(err);
  }
});

// POST /api/projects/:id/members - Admin only
router.post('/:id/members', requireRole('Admin'), async (req, res, next) => {
  try {
    const { userId } = req.body;
    if (!mongoose.isValidObjectId(userId)) {
      return res.status(400).json({ message: 'Invalid user id' });
    }
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!project.members.some((m) => String(m) === String(userId))) {
      project.members.push(userId);
      await project.save();
    }
    const populated = await project.populate([
      { path: 'owner', select: 'name email role' },
      { path: 'members', select: 'name email role' },
    ]);
    res.json(populated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/projects/:id/members/:userId - Admin only
router.delete('/:id/members/:userId', requireRole('Admin'), async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    project.members = project.members.filter(
      (m) => String(m) !== String(req.params.userId)
    );
    await project.save();
    const populated = await project.populate([
      { path: 'owner', select: 'name email role' },
      { path: 'members', select: 'name email role' },
    ]);
    res.json(populated);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
